# BRB — architektura ścieżki UEFI x86-64

Status: **[PROJEKT]**. Odwołania do specyfikacji: „Unified Extensible Firmware Interface (UEFI)
Specification, Release 2.10” (UEFI Forum, 2022). Numery rozdziałów podano według wydania 2.10 i należy je
potwierdzić podczas implementacji. Fakty o repozytorium: `audyt-rozruchu.md`.

---

## 1. Cel i zakres

BRB-UEFI jest aplikacją UEFI (PE32+, `IMAGE_SUBSYSTEM_EFI_APPLICATION` = 10, maszyna `0x8664`). Zadania:

1. Odczytać konfigurację, jądro i moduły z nośnika rozruchowego.
2. Zwalidować je (`bezpieczenstwo.md`).
3. Ustawić tryb graficzny GOP w formacie XRGB8888.
4. Zebrać RSDP i mapę pamięci, zakończyć usługi rozruchowe (`ExitBootServices`).
5. Przekazać sterowanie zgodnie z `protokol-rozruchowy.md`.

BRB nie implementuje sterowników sprzętu, jeśli istnieje udokumentowany protokół UEFI.

---

## 2. Rozmieszczenie na nośnikach

### 2.1. Ścieżka domyślna nośnika wymiennego

UEFI 2.10, rozdz. 3.5.1.1 (*Removable Media Boot Behavior*): na x64 domyślną ścieżką jest
`\EFI\BOOT\BOOTX64.EFI` na partycji systemowej EFI (FAT). **[FAKT]** Obecny instalator zapisuje tam GRUB
(`storage_format.cpp:400`). Jądro nie wywołuje żadnych usług UEFI (Z-12), więc instalator nie tworzy zmiennych
`Boot####` — firmware uruchamia plik jako domyślny program nośnika. **[WNIOSEK]** BRB może przejąć dokładnie tę
ścieżkę bez zmiany układu ESP.

### 2.2. Nazewnictwo artefaktów BRB

| Artefakt | Nazwa robocza (Fazy 2–14) | Nazwa produkcyjna (po decyzji migracji) |
|---|---|---|
| aplikacja UEFI | `.brb-build/uefi/brb-x64.efi` | na ESP: `\EFI\BOOT\BOOTX64.EFI` |
| kopia rezerwowa | — | `\EFI\BURSZTYN\BRB-X64.EFI` (sekcja 2.3) |
| konfiguracja | `\EFI\BURSZTYN\BRB.CFG` | jw. |
| ISO eksperymentalne | `BursztynOS-BRB-eksperymentalny.iso` | — (nigdy `BursztynOS.iso` przed decyzją) |

### 2.3. Ponowne użycie obecnego ESP zainstalowanego systemu

**[FAKT]** ESP ma 512 MiB, klastry 4 KiB, zajęte jest kilkanaście MiB, a pliki są ciągłe. **[WNIOSEK]** BRB
może czytać istniejące `\BOOT\JADRO_A.BIN`/`\BOOT\JADRO_B.BIN` i nie wymaga przebudowy ESP. Dodatkowy
katalog `\EFI\BURSZTYN\` (BRB, konfiguracja, kopia GRUB na czas przejścia) mieści się w wolnym miejscu.
Zapis wymaga sterownika FAT32 z alokacją klastrów albo użycia `EFI_FILE_PROTOCOL.Write` — integracja w
`integracja-instalatora.md`.

---

## 3. Protokoły UEFI używane przez BRB

| Protokół / usługa | Rozdział UEFI 2.10 | Użycie | Alternatywa przy braku |
|---|---|---|---|
| `EFI_SYSTEM_TABLE`, `EFI_BOOT_SERVICES` | 4.3, 4.4 | wejście, usługi | — (brak = firmware niezgodny) |
| `EFI_LOADED_IMAGE_PROTOCOL` | 9.1 | `DeviceHandle` nośnika BRB, `FilePath`, `ImageBase/ImageSize` (wykluczenie obrazu BRB z celów kopiowania) | — (wymagany) |
| `EFI_DEVICE_PATH_PROTOCOL` | 10 | identyfikacja nośnika: węzły `HardDrive` (GUID partycji GPT), `CDROM`, `USB` | rekord źródła niewypełniony |
| `EFI_SIMPLE_FILE_SYSTEM_PROTOCOL` + `EFI_FILE_PROTOCOL` | 13.4, 13.5 | odczyt plików z FAT (ESP, `efi.img` ISO) | `EFI_BLOCK_IO` + własny czytnik FAT/ISO9660 (Faza 6) |
| `EFI_BLOCK_IO_PROTOCOL` / `EFI_DISK_IO_PROTOCOL` | 13.9 / 13.7 | odczyt ISO9660 z dysku nadrzędnego (Live), surowe LBA 2046/2047 | brak funkcji zależnych |
| `EFI_GRAPHICS_OUTPUT_PROTOCOL` | 12.9 | `QueryMode`, `SetMode`, `Mode->FrameBufferBase/Size`, `PixelFormat`, `PixelsPerScanLine` | start bez grafiki niemożliwy dla obecnego jądra (Z-05) → komunikat |
| `EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL` | 12.4 | komunikaty tekstowe przed GOP i przy błędach | port szeregowy |
| `EFI_SIMPLE_TEXT_INPUT_PROTOCOL` (`…_EX` opcjonalnie) | 12.3 | menu (Faza 11), klawisze | brak menu → wpis domyślny |
| `EFI_SERIAL_IO_PROTOCOL` | 12.8 | opcjonalny log; domyślnie BRB pisze bezpośrednio do COM1 0x3F8 jak jądro | — |
| `GetMemoryMap`, `AllocatePages`, `AllocatePool`, `FreePages/FreePool` | 7.2 | pamięć | — |
| `ExitBootServices` | 7.4 | koniec usług | — |
| `Stall`, `SetWatchdogTimer`, `CreateEvent/SetTimer/WaitForEvent` | 7.5, 7.1 | limit czasu menu; wyłączenie watchdoga menedżera rozruchu | — |
| `GetVariable`/`SetVariable` | 8.2 | **nie w v1** (stan A/B jest na dysku, nie w NVRAM) | — |
| `ResetSystem` | 8.5.1 | menu: „Uruchom ponownie”, „Wyłącz komputer” | brak pozycji w menu |
| Tabela konfiguracji `EFI_ACPI_20_TABLE_GUID`, `ACPI_TABLE_GUID`, `SMBIOS(3)_TABLE_GUID` | 4.6 | RSDP, SMBIOS | rekord pominięty |

BRB **nie** używa: sieci (PXE, HTTP Boot), `LoadImage/StartImage` dla jądra (jądro nie jest PE),
`SetVirtualAddressMap`, protokołów Secure Boot innych niż odczyt zmiennej `SecureBoot` w celach diagnostycznych
(`bezpieczenstwo.md`).

---

## 4. Lokalizacja nośnika i konfiguracji

```
efi_main(ImageHandle, SystemTable)
  ├─ SetWatchdogTimer(0, …)                        – wyłączenie watchdoga ustawionego przez menedżera rozruchu (opis SetWatchdogTimer, rozdz. 7.5)
  ├─ HandleProtocol(ImageHandle, LoadedImage)      → DeviceHandle (partycja/obraz FAT, z którego uruchomiono BRB)
  ├─ HandleProtocol(DeviceHandle, SimpleFileSystem) → wolumin BRB
  ├─ Open "\EFI\BURSZTYN\BRB.CFG"                  – brak/uszkodzony → konfiguracja wbudowana (wpis domyślny)
  ├─ ustalenie rodzaju nośnika (DevicePath):
  │     CDROM node        → Live z ISO (rodzaj 1)
  │     HardDrive + GPT   → odczyt LBA 2046/2047 dysku nadrzędnego (BlockIO) → zainstalowany (rodzaj 3),
  │                         gdy rekord stanu poprawny; inaczej nośnik wymienny/obraz hybrydowy (rodzaj 2)
  └─ ścieżki plików zawsze względem tego samego woluminu (brak wyszukiwania po innych dyskach)
```

**Uzasadnienie braku wyszukiwania po wszystkich dyskach** **[PROJEKT]**: obecny GRUB robi
`search --file /EFI/BOOT/BOOTX64.EFI`, co może trafić na **inny** dysk z takim samym plikiem. BRB ładuje
pliki wyłącznie z woluminu, z którego sam został uruchomiony. Eliminuje to pomyłkę dysku przy kilku
instalacjach albo podłączonym nośniku instalacyjnym.

---

## 5. Ładowanie jądra ELF64

**[FAKT]** Jądro jest ELF64 `ET_EXEC` z 4 segmentami `PT_LOAD` o stałych adresach fizycznych od 1 MiB
(`audyt-rozruchu.md`, sekcja 2). BRB ładuje je jako ELF64. Formatu PE dla jądra nie przewiduje się.

### 5.1. Walidacja (kolejność, każde niepowodzenie = odmowa z komunikatem)

| # | Kontrola | Specyfikacja |
|---|---|---|
| 1 | rozmiar pliku ≥ 64 i ≤ 64 MiB (limit BRB); plik czytany w całości do bufora `EfiLoaderData` | — |
| 2 | `e_ident`: `\x7FELF`, `ELFCLASS64`, `ELFDATA2LSB`, `EV_CURRENT`; OS/ABI ∈ {0 (SYSV), 3 (GNU)} | System V gABI, rozdz. 4 *ELF Header* |
| 3 | `e_type == ET_EXEC`, `e_machine == EM_X86_64 (62)`, `e_version == 1` | gABI |
| 4 | `e_ehsize == 64`, `e_phentsize == 56`, `1 ≤ e_phnum ≤ 16`, `e_phoff + e_phnum·56 ≤ rozmiar` (bez przepełnienia) | gABI |
| 5 | dla każdego `PT_LOAD`: `p_filesz ≤ p_memsz`, `p_offset + p_filesz ≤ rozmiar`, `p_paddr + p_memsz` bez przepełnienia, `p_paddr ≥ 1 MiB`, `p_paddr + p_memsz ≤ 4 GiB`, `p_align` ∈ {0, 1, potęga 2}, `(p_offset − p_paddr) % 4096 == 0` przy `p_align = 4096` | gABI rozdz. 5 *Program Header* |
| 6 | segmenty `PT_LOAD` są posortowane rosnąco po `p_paddr` i nie nakładają się | gABI (kolejność) + wymaganie BRB |
| 7 | brak `PT_INTERP`, `PT_DYNAMIC`, `PT_TLS` (jądro statyczne); `PT_GNU_STACK`/`PT_NOTE` ignorowane | — |
| 8 | żaden segment nie jest jednocześnie W i X (zgodnie z polityką `linker.ld:91–97`); naruszenie → odmowa | wymaganie BRB |
| 9 | nagłówek MB2 w pierwszych 32 KiB z poprawną sumą (tryb zgodności) albo `brb_naglowek_jadra` (natywny) | MB2 §3.1 |
| 10 | adres wejścia (`e_entry` albo `wejscie64`) leży w segmencie wykonywalnym | `linker.ld:465–468` |
| 11 | zakres `[min p_paddr, max p_paddr+p_memsz)` mieści się w RAM możliwym do użycia po `ExitBootServices` (sekcja 6.2) | wymaganie BRB |
| 12 | w systemie zainstalowanym: SHA-256 pliku jądra = `sha256_jadro_{a,b}` ze stanu LBA, gdy pole niezerowe | `aktualizacja_rozruch.h:88–89` |

### 5.2. Plan ładowania

Segmenty są ładowane pod stałe adresy fizyczne 1 MiB…`__kernel_end`. Na rzeczywistym sprzęcie UEFI ten zakres
**może być zajęty** przez firmware jako `EfiBootServicesData/Code` (usługi rozruchowe). Taka pamięć jest
wolna dopiero po `ExitBootServices`. Dlatego BRB stosuje model **przygotuj teraz, skopiuj po EBS**:

1. Próba `AllocatePages(AllocateAddress, EfiLoaderData, …)` dla zakresu jądra. Sukces → kopiowanie
   segmentów od razu (ścieżka szybka, typowa dla OVMF).
2. Porażka → bufor przejściowy `AllocatePages(AllocateMaxAddress < 4 GiB, EfiLoaderData)`, segmenty składane
   w buforze (z wyzerowanym BSS). Plan przeniesienia `{źródło, cel, długość}` zapisany w strukturze trampoliny.
3. Warunek ścieżki 2: każdy fragment docelowego zakresu w ostatecznej mapie pamięci jest typu
   `EfiConventionalMemory`, `EfiBootServicesCode/Data` albo `EfiLoaderCode/Data` należącego do BRB. Inny typ
   (Runtime, ACPI, MMIO, Reserved) → odmowa: „Pamięć wymagana przez jądro jest zajęta przez firmware.”
4. Bufory trampoliny, MBI/BRBI, stos, GDT i tablice stron BRB są alokowane **poza** zakresem jądra
   (`AllocateMaxAddress` z wykluczeniem kolizji) i poza obrazem BRB (`ImageBase … ImageBase+ImageSize`).

BSS (`p_memsz − p_filesz`) jest **zawsze zerowane przez BRB** (D-11).

---

## 6. Alokacja pamięci i zapobieganie nakładaniu

### 6.1. Rejestr zakresów BRB

Wszystkie obszary przekazywane jądru BRB zapisuje w stałej tablicy `brb_zakres[256]` (bez alokacji
dynamicznej). Każdy wpis ma rodzaj: JĄDRO, MODUŁ(n), INFORMACJE, STOS, GDT, TABLICE_STRON, TRAMPOLINA,
FRAMEBUFFER. Przy dodawaniu wpisu BRB sprawdza przepełnienie `poczatek + dlugosc` i rozłączność z każdym
istniejącym wpisem (O(n²) przy n ≤ 256 — akceptowalne). Rejestr jest źródłem wpisów typu 0x100–0x103 w mapie.

### 6.2. Typy pamięci UEFI a cel kopiowania po EBS

| Typ UEFI (UEFI 2.10, rozdz. 7.2, tabela *Memory Type Usage after ExitBootServices*) | Może być celem jądra/modułów po EBS |
|---|---|
| `EfiConventionalMemory`, `EfiBootServicesCode`, `EfiBootServicesData`, `EfiLoaderCode`, `EfiLoaderData` | tak |
| `EfiRuntimeServicesCode/Data`, `EfiACPIReclaimMemory`, `EfiACPIMemoryNVS`, `EfiReservedMemoryType`, `EfiUnusableMemory`, `EfiMemoryMappedIO*`, `EfiPalCode`, `EfiPersistentMemory`, `EfiUnacceptedMemoryType`, nieznane | nie |

### 6.3. Tablice stron i GDT

**[FAKT]** Tablice stron firmware leżą w pamięci usług rozruchowych, którą po EBS wolno nadpisać, i nie
gwarantują identity map całego zakresu < 4 GiB. **[PROJEKT]** Przed EBS BRB:

- alokuje własne PML4/PDPT/4 × PD (identity 0..4 GiB, strony 2 MiB — identycznie jak `boot.S`) w
  `EfiLoaderData` poza celami kopiowania,
- alokuje własną GDT (null, 0x08 kod64, 0x10 dane, 0x18 kod32, 0x20 dane32) i stos 64 KiB.

Po EBS, przed kopiowaniem czegokolwiek, BRB przełącza `CR3`, GDT i `RSP` na te struktury.

---

## 7. GOP — wybór trybu graficznego

1. `LocateHandleBuffer(ByProtocol, GOP)`. Pierwszeństwo ma uchwyt, który ma też `EFI_DEVICE_PATH` urządzenia
   PCI (konsola rzeczywista). Wiele uchwytów → pierwszy pasujący.
2. Dopuszczalne tryby: `PixelBlueGreenRedReserved8BitPerColor` (w pamięci B,G,R,X = XRGB8888 w słowie
   32-bit LE — zgodny z Z-05) albo `PixelBitMask` z maskami R=0x00FF0000, G=0x0000FF00, B=0x000000FF.
   `PixelRedGreenBlueReserved8BitPerColor` (XBGR8888) jest **niezgodny z obecnym jądrem** — pomijany do czasu
   obsługi w jądrze. `PixelBltOnly` (brak LFB) — niedostępny.
3. Wybór rozdzielczości:
   - wartość z konfiguracji (`grafika = 1280x720`) albo z parametru `bursztyn.video=`;
   - w przeciwnym razie 1280×720, jak obecny `gfxmode` (`Makefile:1315`);
   - w przeciwnym razie największy tryb ≤ 1920×1080;
   - w przeciwnym razie tryb bieżący, jeśli zgodny.
4. `SetMode` tylko wtedy, gdy wybrany tryb ≠ bieżący. Po `SetMode` ekran jest czyszczony na czarno (bez migania
   — jądro i tak rysuje ekran powitalny).
5. `pitch = PixelsPerScanLine × 4`; `rozmiar = max(FrameBufferSize, pitch × VerticalResolution)`.
   Sprawdzenie: szerokość, wysokość ≥ 64; `pitch × wysokość` bez przepełnienia.
6. Brak zgodnego trybu → komunikat tekstowy (ConOut + COM1):
   „Nie znaleziono trybu graficznego zgodnego z Bursztyn OS (wymagany 32-bitowy XRGB). Uruchomienie nie jest
   możliwe.” Po nim powrót do menu albo `ResetSystem` po naciśnięciu klawisza.

---

## 8. ACPI i SMBIOS z tabeli konfiguracji

- Przeszukanie `SystemTable->ConfigurationTable[0..NumberOfTableEntries)` (limit 256 wpisów).
- Pierwszeństwo `EFI_ACPI_20_TABLE_GUID` (8868E871-E4F1-11D3-BC22-0080C73C8881), potem `ACPI_TABLE_GUID`
  (EB9D2D30-2D88-11D3-9A16-0090273FC14D).
- Walidacja RSDP: sygnatura `"RSD PTR "`, suma 20 B, a dla rewizji ≥ 2 suma po `Length` (≤ 36 przy kopiowaniu,
  `Length` ≥ 36). Kopia trafia do rekordu 4 / tagu 14/15. Jądro dalej waliduje RSDT/XSDT samo (`acpi.cpp`).
- SMBIOS: `SMBIOS3_TABLE_GUID` (F2FD1544-9794-4A2C-992E-E5BBCF20E394), potem `SMBIOS_TABLE_GUID`
  (EB9D2D31-2D88-11D3-9A16-0090273FC14D). W v1 przekazywany jest tylko adres (rekord 8, opcjonalny).

---

## 9. Mapa pamięci i `ExitBootServices`

Zgodnie z UEFI 2.10, rozdz. 7.4: `ExitBootServices(ImageHandle, MapKey)` wymaga klucza aktualnej mapy.
Przy `EFI_INVALID_PARAMETER` loader musi ponownie pobrać mapę i ponowić wywołanie, a między nimi **nie wolno**
wywoływać usług, które mogą zmienić mapę.

### 9.1. Algorytm

```
przygotuj WSZYSTKO, co wymaga alokacji: jądro, moduły, bufor MBI/BRBI (rozmiar maksymalny), tablice stron,
GDT, stos, trampolinę, bufor mapy pamięci = (rozmiar zgłoszony + 16 deskryptorów) * DescriptorSize, ×2
zamknij pliki, zwolnij bufory tymczasowe (FreePool) – zmiany mapy dozwolone tylko do tego momentu

for proba in 1..4:                                  // ograniczona liczba prób
    rozmiar = pojemnosc_bufora
    s = GetMemoryMap(&rozmiar, bufor, &MapKey, &DescSize, &DescVer)
    if s == EFI_BUFFER_TOO_SMALL: → błąd krytyczny (bufor był przewymiarowany; brak AllocatePool w pętli)
    if s != EFI_SUCCESS:          → błąd krytyczny
    if DescSize < sizeof(EFI_MEMORY_DESCRIPTOR) or DescVer != 1 or rozmiar % DescSize != 0: → błąd
    // ŻADNYCH wywołań usług (w tym ConOut, Stall, AllocatePool) między GetMemoryMap a ExitBootServices
    s = ExitBootServices(ImageHandle, MapKey)
    if s == EFI_SUCCESS: break
    if s != EFI_INVALID_PARAMETER: → błąd krytyczny
koniec pętli bez sukcesu → błąd krytyczny „Nie udało się zakończyć usług rozruchowych UEFI.”
```

Uwagi:

- Komunikat o błędzie po nieudanym EBS może jeszcze użyć ConOut **tylko**, gdy wszystkie próby zwróciły
  błąd (usługi nadal aktywne). Po sukcesie EBS BRB używa wyłącznie COM1 (`outb`) i nie dotyka `SystemTable`
  poza polami skopiowanymi wcześniej.
- Po `ExitBootServices` BRB normalizuje mapę z kopii pobranej tuż przed EBS (ostatnia udana `GetMemoryMap`).
  Normalizacja jest czystą funkcją bez alokacji, testowaną na hoście (`plan-testow.md`, T-MAP).
- Liczba prób trafia do rekordu diagnostycznego.

### 9.2. Normalizacja mapy

1. Deskryptory przekształcane do `{poczatek = PhysicalStart, dlugosc = NumberOfPages × 4096, typ}`. Kontrola
   przepełnienia `NumberOfPages × 4096` i `PhysicalStart + dlugosc`.
2. Odrzucenie deskryptorów niewyrównanych do 4 KiB (licznik w diagnostyce).
3. Sortowanie (sortowanie przez wstawianie, ≤ 4096 wpisów) i rozstrzyganie nakładań wg priorytetu typów
   (`protokol-rozruchowy.md`, 6.1).
4. „Wycięcie” zakresów z rejestru BRB (jądro, moduły, informacje, obszar odzyskiwalny) i nadanie im typów
   0x100–0x103 albo typu 2 w trybie zgodności MB2.
5. Scalenie sąsiadów tego samego typu.
6. Kontrola, że rejestr BRB w całości leży w pamięci dopuszczalnej według tabeli z sekcji 6.2.

Rozmiar wyniku jest ograniczony z góry: każde wycięcie dodaje ≤ 2 wpisy, więc ≤ n + 2·256. Bufor wyniku
alokowany przed EBS.

---

## 10. Przejście do jądra (trampolina)

Trampolina to kod asemblerowy BRB umieszczony w osobnej stronie `EfiLoaderData` poniżej 4 GiB, poza
zakresami jądra i modułów. Wymaga identity map, bo w trybie zgodności wyłącza stronicowanie.

### 10.1. Wspólna część (po EBS)

```
cli
lgdt  gdt_brb                     ; własna GDT
mov   cr3, pml4_brb               ; własne identity 0..4 GiB
mov   rsp, stos_brb_szczyt        ; RSP % 16 == 0
dalekie przeładowanie CS = 0x08, DS/ES/SS = 0x10
dla każdego wpisu planu przeniesienia: memmove(cel, zrodlo, dlugosc)   ; kopiowanie bez użycia SSE
wyzeruj ewentualne pozostałości BSS (gdy BSS nie mieściło się w buforze)
oblicz CRC32 BRBI (natywny) – opcjonalnie ponowna kontrola SHA-256 jądra w pamięci docelowej (diagnostyka)
COM1: "[BRB] przekazanie"
```

### 10.2. Tryb natywny (BRBI)

```
mov edi, 0x31425242 ; RDI = magic
mov rsi, brbi_fiz
xor edx, edx ; pozostałe GPR = 0
push 0x2 ; popfq → RFLAGS = 0x2
jmp  wejscie64
```

### 10.3. Tryb zgodności MB2 (wejście 32-bit do `_start`)

Zgodnie z Intel SDM tom 3A, rozdział o inicjalizacji i wyłączaniu trybu IA-32e (*Initializing IA-32e Mode*,
*IA-32e Mode Deactivation*):

```
ljmp  0x18:tryb_zgodnosci32       ; segment kodu 32-bit (L=0, D=1) – compatibility mode
.code32
tryb_zgodnosci32:
mov   ax, 0x20 ; ds, es, fs, gs, ss = 0x20 (dane 32-bit)
mov   eax, cr0 ; and eax, ~0x80000000 ; mov cr0, eax     ; PG = 0 (wykonywane z identity map)
mov   ecx, 0xC0000080 ; rdmsr ; and eax, ~0x100 ; wrmsr  ; EFER.LME = 0
mov   eax, cr4 ; and eax, ~0x20 ; mov cr4, eax           ; PAE = 0 (porządek)
mov   esp, stos_brb32
mov   eax, 0x36D76289
mov   ebx, mbi_fiz
jmp   e_entry                     ; _start w jądrze (boot.S:215)
```

### 10.4. Różnice konwencji wywołań

- Kod BRB wywołujący usługi UEFI używa konwencji Microsoft x64 (UEFI 2.10, rozdz. 2.3.4):
  argumenty w RCX, RDX, R8, R9, 32 B *shadow space*, stos wyrównany do 16 B przed `call`, rejestry
  nieulotne RBX, RBP, RDI, RSI, R12–R15, XMM6–XMM15.
- Kod wewnętrzny BRB kompilowany GCC ma konwencję System V. Wszystkie typy wskaźników funkcji UEFI są więc
  oznaczone `__attribute__((ms_abi))`, a `efi_main` jest zadeklarowane jako `ms_abi`. Nie miesza się kodu
  `-mabi=ms` z kodem SysV w jednej funkcji.
- Firmware może używać SSE: BRB kompilowany z `-mgeneral-regs-only` nie używa rejestrów XMM, więc nie musi ich
  zachowywać (kompilator nie wygeneruje ich użycia).
- Przekazanie do jądra nie jest wywołaniem funkcji. Stan rejestrów jest w całości zdefiniowany w
  `protokol-rozruchowy.md`, sekcja 2.

---

## 11. Obsługa błędów

| Sytuacja | Zachowanie | Komunikat (PL) |
|---|---|---|
| brak `LoadedImage`/`SimpleFileSystem` | powrót do firmware (`return EFI_LOAD_ERROR`) po 10 s | „Nie można odczytać nośnika, z którego uruchomiono program rozruchowy.” |
| brak/uszkodzona konfiguracja | wbudowany wpis domyślny + ostrzeżenie | „Plik konfiguracji BRB jest uszkodzony — używam ustawień domyślnych.” |
| brak pliku jądra | menu/następny wpis; w systemie A/B: drugi slot zgodnie z polityką | „Nie znaleziono pliku jądra: <ścieżka>.” |
| niepoprawny ELF / niezgodna architektura | jw. | „Plik jądra jest uszkodzony lub nie jest obrazem x86-64.” |
| niezgodność SHA-256 slotu | traktowane jak nieudana próba slotu | „Suma kontrolna jądra slotu B jest niezgodna — powrót do slotu A.” |
| brak pamięci (`AllocatePages`) | odmowa | „Za mało pamięci, aby załadować system.” |
| CPU bez Long Mode/PAE/NX (sprawdzane CPUID przed EBS) | odmowa | „Procesor nie spełnia wymagań Bursztyn OS (x86-64 z PAE i NX).” |
| moduł uszkodzony / za duży / zbyt wiele modułów | wpis Live: odmowa; moduł opcjonalny (galeria, muzyka): pominięcie + ostrzeżenie | „Moduł <etykieta> jest uszkodzony.” |
| niepowodzenie `ExitBootServices` po 4 próbach | odmowa, usługi nadal aktywne | „Nie udało się zakończyć usług rozruchowych UEFI.” |
| awaria po EBS (np. błąd kontroli przed skokiem) | COM1 + `cli; hlt` (brak usług) | `"[BRB] BLAD KRYTYCZNY <kod>"` (ASCII na COM1) |

Wszystkie komunikaty dla użytkownika są po polsku. ConOut UEFI przyjmuje UCS-2, więc BRB konwertuje teksty
UTF-8 na UCS-2. Polskie znaki (ą, ć, ę, ł, ń, ó, ś, ź, ż) mieszczą się w BMP. Ich wyświetlenie zależy od fontu
firmware. **[DO POTWIERDZENIA]** Część firmware nie ma glifów spoza ASCII, a braku glifów nie da się
niezawodnie wykryć. Dlatego konfiguracja ma opcję `tekst_ascii = tak` (transliteracja bez polskich znaków)
dla trybu tekstowego. Menu graficzne (Faza 11) rysuje własnym fontem i tego problemu nie ma.

---

## 12. Budowanie aplikacji UEFI — wymagania i otwarta decyzja

**[FAKT]** Dostępne: GCC 13.3 (`x86_64-linux-gnu-`), GNU ld 2.42 z emulacją `i386pep`, objcopy z
`pei-x86-64`. Niedostępne: clang/lld-link, MinGW.

**[PROJEKT]** Dwie metody do sprawdzenia w Fazie 2 (spike):

| Metoda | Opis | Zalety | Ryzyka |
|---|---|---|---|
| A | kompilacja `-ffreestanding -fno-pic -mno-red-zone -mgeneral-regs-only -fno-stack-protector -fshort-wchar -fno-asynchronous-unwind-tables`, linkowanie `x86_64-linux-gnu-ld -m i386pep --subsystem 10 -e efi_main --image-base 0x… --file-alignment 0x200 --section-alignment 0x1000` z relokacjami bazowymi (`.reloc`) | standardowy PE32+ z relokacjami tworzonymi przez linker | zachowanie GNU ld przy wejściu ELF → wyjście PE trzeba zweryfikować (sekcje, relokacje `R_X86_64_64`) |
| B | link do ELF `-shared -Bsymbolic -pie` + własna samorelokacja (`_DYNAMIC`, `R_X86_64_RELATIVE`) + `objcopy --target=efi-app-x86_64` | metoda znana z praktyki (bez użycia kodu gnu-efi) | własny kod samorelokacji do napisania i przetestowania; „pusty” `.reloc` |

Kryteria akceptacji (obie metody):

- `objdump -p` pokazuje `PE32+`, `Subsystem 0000000a`, maszynę `8664` i sekcję `.reloc` z wpisami;
- brak sekcji W+X;
- obraz uruchamia się w OVMF i wypisuje `[BRB] etap 1: wejscie` na COM1;
- test hosta parsuje własny PE (nagłówki, relokacje) i odrzuca błędy.

Rekomendacja: A, jeśli spełni kryteria. W przeciwnym razie B.

Funkcje wspierające kompilator (`memcpy`, `memset`, `memmove`, `memcmp`) BRB implementuje samodzielnie
(GCC może je generować nawet z `-ffreestanding`). `-mno-stack-arg-probe` nie dotyczy celu ELF. Nie
linkujemy `libgcc`, jeśli nie jest potrzebne: BRB unika dzielenia 128-bit i operacji zmiennoprzecinkowych.
**[DO POTWIERDZENIA]** weryfikacja `nm -u` w Fazie 2 (lista symboli niezdefiniowanych musi być pusta).

---

## 13. Kamienie milowe na porcie szeregowym (UEFI)

Wypisywane na COM1 (0x3F8, 38400 8N1, jak jądro), w ASCII, z prefiksem `[BRB]`:

| Kod | Tekst | Moment |
|---|---|---|
| U1 | `[BRB] etap 1: wejscie UEFI` | początek `efi_main` |
| U2 | `[BRB] etap 2: nosnik i konfiguracja` | po otwarciu woluminu i konfiguracji |
| U3 | `[BRB] etap 3: jadro zaladowane i zweryfikowane` | po walidacji ELF/SHA |
| U4 | `[BRB] etap 4: moduly n=<liczba>` | po modułach |
| U5 | `[BRB] etap 5: grafika <szer>x<wys>` | po GOP |
| U6 | `[BRB] etap 6: ExitBootServices proby=<n>` | po EBS |
| U7 | `[BRB] etap 7: przekazanie <MB2/BRBI> wejscie=<hex>` | tuż przed skokiem |

Kolejnym znakiem życia jest log jądra (`BootTiming::entry`, linie COM1 jądra).
